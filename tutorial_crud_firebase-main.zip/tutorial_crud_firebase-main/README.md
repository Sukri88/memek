# Tutorial CRUD Firebase
ini adalah file dari tutorial youtube
https://youtu.be/R8xkkoJg-nM
